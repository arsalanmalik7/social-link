const isProduction = window.location.href.includes("https");

export const baseUrl = isProduction ? "" : "http://aws-app.eu-north-1.elasticbeanstalk.com";