import React from "react";
import './chat.css'

const Chat = ()=>{
    return(
        <div>
            <h1>Coming Soon</h1>
        </div>
    )
}

export default Chat;